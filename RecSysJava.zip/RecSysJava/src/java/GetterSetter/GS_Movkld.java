/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GetterSetter;

/**
 *
 * @author Hp
 */
public class GS_Movkld {
    String movid;
    Double action;
    Double adventure;
    Double animation;
    Double comedy;
    Double crime;
    Double drama;
    

    

    public Double getAction() {
        return action;
    }

    public void setAction(Double action) {
        this.action = action;
    }

    public Double getAdventure() {
        return adventure;
    }

    public void setAdventure(Double adventure) {
        this.adventure = adventure;
    }

    public Double getAnimation() {
        return animation;
    }

    public void setAnimation(Double animation) {
        this.animation = animation;
    }

    public Double getComedy() {
        return comedy;
    }

    public void setComedy(Double comedy) {
        this.comedy = comedy;
    }

    public Double getCrime() {
        return crime;
    }

    public void setCrime(Double crime) {
        this.crime = crime;
    }

    public Double getDrama() {
        return drama;
    }

    public void setDrama(Double drama) {
        this.drama = drama;
    }
    
    public String getMovid() {
        return movid;
    }

    public void setMovid(String movid) {
        this.movid = movid;
    }
}
