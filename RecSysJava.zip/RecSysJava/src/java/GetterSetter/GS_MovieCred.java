package GetterSetter;

import Algorithm.KLDivergence;
/**
 *
 * @author Shail Shah
 */
public class GS_MovieCred {
    KLDivergence kld;
    
        
}
